#include<stdio.h>

struct node{
	int data;
	struct node *next;
	
}*head,*ptr,*newnode;

int main()
{head=NULL;
	int num ;
	char ch='y';
	
	while(ch=='y'){
		printf("enter the node\n");
		newnode= (struct node *) malloc(sizeof(head));
			scanf("%d",&num);
		newnode->data=num;
		if(head==NULL)
		{
			newnode->next=NULL;
			head=newnode;
		}
		else{ptr=head;
		while (ptr->next!=NULL)
		{
			ptr=ptr->next;
		}
		ptr->next=newnode;
		newnode->next=NULL;
		
		}

	ptr=head;
	printf("the list is\n");
	while(ptr!=NULL)
	{
	printf("%d,",ptr->data);
	ptr=ptr->next;	
	}
	printf("\ndo you want to continue\n");
		scanf(" %c",&ch);	
	//system("cls");	
	};
	
	return 0;
}


