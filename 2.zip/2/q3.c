#include<stdio.h>
struct node{
	int data;
	struct node *next;
	
}*head,*ptr,*newnode,*a,*b,*c;


int main()
{
	head=NULL;
	int num ;
	char ch='y';
	
	while(ch=='y'){
		printf("\n");
		printf("enter the node\n");
		newnode= (struct node *) malloc(sizeof(head));
			scanf("%d",&num);
		newnode->data=num;
		if(head==NULL)
		{
			newnode->next=NULL;
			head=newnode;
		}
		else{ptr=head;
		while (ptr->next!=NULL)
		{
			ptr=ptr->next;
		}
		ptr->next=newnode;
		newnode->next=NULL;
		
		}
	printf("\n do you want to continue\n");
    scanf(" %c",&ch);	
	ptr=head;
	printf("the list is\n");
	while(ptr!=NULL)
	{
	printf("%d,",ptr->data);
	ptr=ptr->next;	
	}
	
		
	};
	a=head;
	b=a->next;
	c=b->next;
	while(c->next!=NULL)
	{
		if(a==head)
		{a->next=NULL;}
		
		b->next=a;
		a=b;
		b=c;
		c=c->next;
		
	}
	c->next=b;head=c;
		ptr=head;
	printf("the list is\n");
	while(ptr!=NULL)
	{
	printf("%d,",ptr->data);
	ptr=ptr->next;	
	}
	
	
	return 0;
}
