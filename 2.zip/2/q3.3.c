#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;
}*head,*newnode,*ptr,*a,*b,*c;


struct node * createll(struct node *head)
{int num;
char a = 'y';
while(a=='y')
{
 newnode = (struct node *) malloc(sizeof(struct node));
	printf("enter the number to insert\n");
	scanf("%d",&num);
	newnode->data=num;
if(head==NULL)
{
	newnode->next=NULL;
	head=newnode;
}
else
{
	ptr=head;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=newnode;
	newnode->next=NULL;
}
printf("do you want to coninue\n");
scanf(" %c",&a);
};
return head;
}



int main()
{	head=NULL;
    head=createll(head);
	ptr=head;
	while(ptr!=NULL)
	{
		printf("%d,",ptr->data);
		ptr=ptr->next;
	}
	b=head;
	a=NULL;
	
	while(b!=NULL)
	{
		c=b->next;
		b->next=a;
		a=b;
		b=c;
	}
	head=a;
	ptr=head;
	printf("\n");
	while(ptr!=NULL)
	{
		printf("%d,",ptr->data);
		ptr=ptr->next;
	}
	return 0;
}
