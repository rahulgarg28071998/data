#include<stdio.h>

struct stud{
	int roll;
	char name[20];
	struct stud *next;
}*head,*newnode,*ptr,*temp;

struct stud * createll(struct stud *head)
{
char a = 'y';
while(a=='y')
{
 newnode = (struct stud *) malloc(sizeof(struct stud));
 printf("enter the name\n");
 scanf("%s",&newnode->name);
 printf("enter the roll number\n");
 scanf("%d",&newnode->roll);
if(head==NULL)
{
	newnode->next=NULL;
	head=newnode;
}
else
{
	ptr=head;
	while(ptr->next!=NULL)
	{
		ptr=ptr->next;
	}
	ptr->next=newnode;
	newnode->next=NULL;
}
printf("do you want to coninue\n");
scanf(" %c",&a);
};
return head;
}

void display(struct stud *head) 
{
	ptr=head;
	while(ptr!=NULL)
	{   printf("the roll no %d and name %s\n",ptr->roll,ptr->name);
		ptr=ptr->next;
	}
	getch();
}

struct stud * insertll(struct stud *head)
{
	int pos,i;
	newnode = (struct stud *) malloc(sizeof(struct stud));
	 printf("enter the name\n");
	 scanf("%s",&newnode->name);
	 printf("enter the roll number\n");
	 scanf("%d",&newnode->roll);
	 printf("enter the position to insert the node\n");
	 scanf("%d",&pos);
	 ptr=head;
	 for( i=pos;i-1>0;i--)
	 {
	 	if(ptr->next!=NULL)
	 	{	temp=ptr;
	 		ptr=ptr->next;
	 		
		 }
	 }
	 temp->next=newnode;
	 newnode->next=ptr;
	 getch();
	 return head;
	 
}

struct stud *deletell(struct node * head)
{	ptr=head;
	int num;
	printf("enter the roll number to delete\n");
	scanf("%d",&num);
	while(ptr!=NULL)
	{
		if(num==ptr->roll)
		{
		temp->next=ptr->next;
		free(ptr);
		break;
		}
		temp=ptr;
		ptr=ptr->next;
	}
	return head;
}

int main()
{
	int num=1;
	head=NULL;
	while(num!=0)
	{
		printf("Menu\n");
		printf("1.create a link list\n");
		printf("2.display link list \n");
		printf("3.insert at given position\n");
		printf("4.delete a given student in list\n");
		printf("Enter 0 to exit\n");
		scanf("%d",&num);
		switch(num)
		{
			case 1 : head=createll(head);
					break;
			case 2 : display(head);
						break;
			case 3 :head=insertll(head);
			        break;
			case 4 : head=deletell(head);
					break;
		}
		system("cls");
	}
return 0;	
}
