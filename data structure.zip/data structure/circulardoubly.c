#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node *create(struct node *);
void display(struct node *);
struct node *insertbeg(struct node *);
struct node *insertlast(struct node *);
struct node *deletebeg(struct node *);
struct node *deletelast(struct node *);


struct node{
			int data ;
			struct node *left;
			struct node *right;
			}*ptr,*head,*newnode,*temp;

int main()
{
	head=NULL;
	char ch='y',c;

	while(c!='7')
	{
   system("cls");	
	printf("menu\n");
	printf("1.create list\n");
	printf("2.display list\n");
	printf("3.insert node at beg\n");
	printf("4.insertnode at last\n");
	printf("5.delet node from beg\n");
	printf("6.delet node from last\n");
	printf("7.to exit\n");
	scanf("%c",&c);
	switch(c)	
	{
	case '1' : head = create(head);
				break;
	case '2' : display(head);
				break;	
	case '3' :head=insertbeg(head);
				break;
	case '4' : head=insertlast(head);	
				break;
	case '5' : head=deletebeg(head);
				break;
	case '6' :head=deletelast(head);
				break;
	default  :printf(" exit\n");
				
	}

	
    }
	
	return 0;
}


struct node *deletelast(struct node *head)
{
	ptr=head;
	while(ptr->right->right!=NULL)
	{
		ptr=ptr->right;
	}
	temp=ptr->right;
	ptr->right=NULL;
	free(temp);
	return head;
}








struct node *create(struct node *head)
{
	printf("enter link list to end enter -1\n");
	int num;
	scanf("%d",&num);
	while(num!=-1)
	{newnode= (struct node *) malloc(sizeof(head));
	newnode->data=num;
		if(head==NULL)
		{
			newnode->right=head;
			head=newnode;
			newnode->left=head;
		}
		else{
		ptr=head;
		while(ptr->right!=head)
		{
			ptr=ptr->right;
		}
		ptr->right=newnode;
		newnode->left=ptr;
		newnode->right=head;
		
		}
		scanf("%d",&num);
	}
	ptr=head;
	while(ptr->right!=head)
	{
	printf("%d,",ptr->data);
	ptr=ptr->right;	
	}
	return head;	
}

void display(struct node *head)
{  printf("displayed list\n");ptr=head;
	while(ptr!=NULL)
	{
	printf("%d,",ptr->data);
	ptr=ptr->right;	
	}
	
}

struct node *insertbeg(struct node *head)
{newnode= (struct node *) malloc(sizeof(head));
	printf("enter the node to isert in beg\n");
	int num;
	scanf("%d",&num);
	newnode->data=num;
	newnode->left=NULL;
	if(head==NULL)
	{
	newnode->right=NULL;
	head=newnode;	
	}
	else
	{
		newnode->right=head;
		head=newnode;
	}
	return head;
}

struct node *insertlast(struct node *head)
{
	newnode= (struct node *) malloc(sizeof(head));
	printf("enter the node to isert in last\n");
	int num;
	scanf("%d",&num);
	newnode->data=num;
		newnode->right=NULL;
		if(head==NULL)
	{
	newnode->left=NULL;
	head=newnode;	
	}
	else{
		ptr=head;
		while(ptr->right!=NULL)
		ptr=ptr->right;
		
		ptr->right=newnode;
		newnode->left=ptr;
		
	}
	return head;
}


struct node *deletebeg(struct node *head)
{
	ptr=head;
	head=head->right;
	free (ptr);
	return head;
}

