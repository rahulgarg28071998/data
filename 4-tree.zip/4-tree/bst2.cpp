#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

struct node{
	int year;char type[20],company[20];
	struct node *left,*right;
}*root,*newnode,*ptr,*preptr,*psuc;

void inorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		inorder(ptr->left);  
		printf("the %s company started in %d year manufactiring %s\n",ptr->company,ptr->year,ptr->type);
		inorder(ptr->right);
	}
}

struct node * insert(struct node *root,int val )
{
	newnode=(struct node *) malloc(sizeof(struct node *));
	newnode->year=val;
	printf("\nenter company name : \n");
	scanf(" %s",newnode->company);
	printf("\nenter the company type :\n");
	scanf(" %s",newnode->type);
	newnode->left=NULL;
	newnode->right=NULL;
	if(root==NULL)
	{
		root=newnode;
		root->left=NULL;
		root->right=NULL;
	}
	else
	{
		preptr=NULL;
		ptr=root;
		 while(ptr!=NULL)
		 {
		 	preptr=ptr;
		 	if(val<ptr->year)
		 	ptr=ptr->left;
		 	else 
		 	ptr=ptr->right;
		 }
		 if(val<preptr->year)
		 preptr->left=newnode;
		 else
		 preptr->right=newnode;
	}inorder(root);
	return root;
}

void preorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		printf("the %s company started in %d year manufactiring %s\n",ptr->company,ptr->year,ptr->type);
		inorder(ptr->left);  
		inorder(ptr->right);
	}
}

void postorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		inorder(ptr->left);  
		inorder(ptr->right);
		printf("the %s company started in %d year manufactiring %s\n",ptr->company,ptr->year,ptr->type);
	}
}
//
//struct node * deletenode(struct node *root)
//{
//	if(root->left==NULL)
//	{
//		printf("the tree is empty\n");return root;
//	}
//	preptr=root;
//	ptr=root->left;
//	while(ptr!=NULL&&val!=ptr->year)
//	{
//		preptr=ptr;
//		ptr=(val<ptr->year?ptr->left:ptr->right);
//	}
//	if(ptr==NULL)
//	{
//		printf("\nvalue not found\n");return root;
//	}
//	if(ptr->left==NULL)
//	 newnode=ptr->right;
//	else if (ptr->right==NULL)
//	`newnode=ptr->left;
//	else
//	{
//	puc=ptr;
//	ptr=ptr->left;
//	while()	
//	}
//}


int main()
{	root=NULL;
	int ch=0;
	while(ch<5)
	{
	printf("menu\n");
	printf("1.insert a node in tree\n");
	printf("2.dispalay inorder\n");
	printf("3.display preorder\n");
	printf("4.display postorder\n");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1: {
				printf("enter the company starting year of tree:\n");
				int val=0;
				scanf("%d",&val);
				root= insert(root,val);
				break;
				}
		case 2 :{
				printf("the tree in order is\n"); 
				inorder(root);
				break;}
		case 3: printf("the tree preorder is\n"); 
				preorder(root);break;
		case 4: printf("the tree postorder is\n"); 
				postorder(root);break;
		//case 5 :root=deletenode(root); 
		default : printf("exiting\n");
	}
	getch();
	system("cls");
	};
}

