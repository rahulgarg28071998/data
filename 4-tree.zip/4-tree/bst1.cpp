#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

struct node{
	int data;
	struct node *left,*right;
}*root,*newnode,*ptr,*preptr;

void inorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		inorder(ptr->left);  
		printf("%d,",ptr->data);
		inorder(ptr->right);
	}

}

struct node * insert(struct node *root,int val )
{
	newnode=(struct node *) malloc(sizeof(struct node *));
	newnode->data=val;
	newnode->left=NULL;
	newnode->right=NULL;
	if(root==NULL)
	{
		root=newnode;
		root->left=NULL;
		root->right=NULL;
	}
	else
	{
		preptr=NULL;
		ptr=root;
		 while(ptr!=NULL)
		 {
		 	preptr=ptr;
		 	if(val<ptr->data)
		 	ptr=ptr->left;
		 	else 
		 	ptr=ptr->right;
		 }
		 if(val<preptr->data)
		 preptr->left=newnode;
		 else
		 preptr->right=newnode;
	}inorder(root);
	return root;
}


void preorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		printf("%d,",ptr->data);
		inorder(ptr->left);  
		inorder(ptr->right);
	}

}

void postorder(struct node * ptr)
{	
	if(ptr!=NULL)
	{
		inorder(ptr->left);  
		inorder(ptr->right);
		printf("%d,",ptr->data);
	}

}
int main()
{	root=NULL;
	int ch=0;
	while(ch<5)
	{
	printf("menu\n");
	printf("1.insert a node in tree\n");
	printf("2.dispalay inorder\n");
	printf("3.display preorder\n");
	printf("4.display postorder\n");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1: {
				printf("enter the node value of tree:\n");
				int val=0;
				scanf("%d",&val);
				root= insert(root,val);
				break;
			}
		case 2 :{
				printf("the tree in order is\n"); 
				inorder(root);
				break;}
		case 3:preorder(root);break;
		case 4:postorder(root);break; 
		default : printf("exiting\n");
	}
	getch();
	system("cls");
	};
}

