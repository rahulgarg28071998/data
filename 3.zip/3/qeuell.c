#include<stdio.h>
#include<stdlib.h>

struct  node {int data;
struct node *next;
}*front,*rear,*ptr,*newnode;

void addq()
{	newnode=(struct node *) malloc(sizeof(struct node *));
	printf("enter the number\n");
	scanf("%d",&newnode->data);
	if(front==NULL&&rear==NULL)
	{
		newnode->next=NULL;
		front = newnode;
		rear= newnode;
	}

	else{
		rear->next=newnode;
		newnode->next=NULL;
		rear=newnode;
	}
}

void deleteq()
{
if(front==NULL&&rear==NULL)
{printf("underflow");}	
else if(front==rear)
{printf("the element deleted is: %d\n",front->data);
front=NULL;
rear=NULL;}
else
{
printf("the element deleted is: %d\n",front->data);
front=front->next;
}
}

void length()
{
	int count =0;
	ptr=front;
	while(ptr!=NULL)
	{
		ptr=ptr->next;
		count++;
	}
	printf("the number of element are:%d",count);
}

void display()
{
ptr=front;printf("the list is:");
while(ptr!=NULL)
{
printf("%d,",ptr->data);
ptr=ptr->next;	
}	
}

int main()
{rear=NULL;front=NULL;
	int ch=0;
	while(ch<4)
	{
		printf("\nmenu for qeue\n1.add entry\n2.delete entry\n3.length of queue\n");
		scanf("%d",&ch);
		switch(ch) 
	{
	case 1:addq();display();break;
	case 2:deleteq();display();break;
	case 3:length();break;
	default:printf("exiting\n");
	};getch();
	system("cls");
	};
	return 0;
}
