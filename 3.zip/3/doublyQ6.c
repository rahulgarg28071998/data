#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
struct emp{
	int id;
	char name[20];
	struct emp *right,*left;
}*front,*rear,*ptr,*newnode;

void insert()
{	newnode=(struct emp *) malloc(sizeof(struct emp *));
	printf("\nenter the employee id:  ");
	scanf("%d",&newnode->id);
	printf("\nenter the name of employee : ");
	scanf("%s",newnode->name);
	newnode->left=NULL;
	if(front==NULL&&rear==NULL)
	{
	newnode->right=NULL;
	front=newnode;rear=newnode;
	}
	else
	{
		newnode->right=front;
		front=newnode;
	}
}

void display()
{printf("\nthe list is : ");
	ptr=front;
	while(ptr!=NULL)
	{
		printf("%d ,",ptr->id);
		printf("%s \n",ptr->name);
		ptr=ptr->right;
	}
}

int main()
{
	int ch=1;
	while(ch<4)
	{
		printf("\nmenu for qeue\n1.add entry\n2.delete entry\n3.length of queue");
		scanf("%d",&ch);
		switch(ch) 
	{
	case 1:insert();display();break;
	case 2://deleteq();display();break;
	case 3://length();break;
	default:printf("exiting\n");
	};getch();
	system("cls");
	}
	
	return 0;
}
