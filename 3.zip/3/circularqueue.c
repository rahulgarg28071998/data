#include<stdio.h>
#include<stdlib.h>

int arr[20];
int front=-1,rear=-1;

void addq()
{  

	if((front==0&&rear==19))
	printf("overflow");
	 int num=0;
	printf("enter the number\n");
	scanf("%d",&num);
	if(front==-1&&rear==-1)
	{
		front=0;rear=0;arr[rear]=num;
	}
	else if(front>0&&rear==19)
	{rear=0;
		arr[rear]=num;
	}
	else {
		rear++;
		arr[rear]=num;
	}
}

void display()
{
	int i=front;
	printf("\nthe queue is : ");
	if(front<=rear)
	{
		while(i<=rear)
		{
			printf("%d,",arr[i]);
			i++;
		}
	}
	else
	{
		while(i<20)
		{
		printf("%d,",arr[i]);
		i++;
		}
		while(i<=rear)
		{
			printf("%d,",arr[i]);
		i++;	
		}
	}
}

void deleteq()
{
	if(front==-1&&rear==-1)
	printf("underflow\n");
	printf("the element to be deleted is: %d\n",arr[front]);
	if(front==rear) {
		front=-1;rear=-1;
	}
	else 
	{
		front++;
	}
}

void length()
{
	int length=0;
	if(front<rear) length=rear-front+1;
	else {
		length=20-front+rear;
	}
	printf("\nthe length is : %d \n",length);
}
int main()
{
	int ch=1;
	while(ch<4)
	{
		printf("\nmenu for qeue\n1.add entry\n2.delete entry\n3.length of queue\n");
		scanf("%d",&ch);
		switch(ch) 
	{
	case 1:addq();display();break;
	case 2:deleteq();display();break;
	case 3:length();break;
	default:printf("exiting\n");
	};getch();
	system("cls");
	}
	
	return 0;
}
