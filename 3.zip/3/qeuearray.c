#include<stdio.h>
#include<stdlib.h>
int arr[20];
int rear=-1,front=-1;

void addq()
{
	int num;
	printf("enter the number\n");
	scanf("%d",&num);
	if(rear==-1&&front==-1)
	{
		rear=0;front=0;arr[0]=num;
	}
	else
	{
		rear++;arr[rear]=num;
	}
}

void display()
{
	int i=front;
	for(i;i<=rear;i++)
	{
		printf("%d,",arr[i]);
	}
}

void deleteq()
{
	if(front==rear)
	{   printf("the deletd node: %d\n",arr[front]);
		front=-1;rear=-1;
	}
	else if(front==-1&&rear==-1)
	{
		printf("\nunderflow\n");
	}
	else
	{printf("node deleted is : %d\n",arr[front]);   
	if(front<20)
		front++;
		else
		front=0;
		
	}
}

void length()
{
	if(front<rear)
	{printf("the lenght is : %d\n",(rear-front));}
	else
	{
		printf("the lenght is : %d\n",(20+rear-front));
	}
}

int main()
{
	int ch=0;
	while(ch<4)
	{
		printf("\nmenu for qeue\n1.add entry\n2.delete entry\n3.length of queue\n");
		scanf("%d",&ch);
		switch(ch) 
	{
	case 1:addq();display();break;
	case 2:deleteq();display();break;
	case 3:length();break;
	default:printf("exiting\n");
	};getch();
	system("cls");
	};
	return 0;
}
