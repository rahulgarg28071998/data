#include<stdio.h>
#include<stdlib.h>
 
struct node {
	int data;
	struct node *next;
}*top,*newnode;

void push()
{   newnode =(struct node *) malloc(sizeof(struct node *));
	printf("enter the data :");
	scanf("%d",&newnode->data);
	
	if(top==NULL)
	{
	newnode->next=NULL;
	top=newnode;	
	}
	else
	{
		newnode->next=top;
		top=newnode;
	}
}
void pop()
{
if(top==NULL){printf("\nunderflow\n");}
else{
	newnode=top;
	top=top->next;
	free(newnode);
}	
}

void display()
{
	newnode=top;
	printf("\nthe stack is\n");
	while(newnode!=NULL)
	{
		printf("%d,",newnode->data);
		newnode=newnode->next;
	}
}
void peep()
{
	printf("the top of stack is:%d",top->data);
}
int main()
{
	int ch=0;top=NULL;
		while(ch<=3)
	{printf("menu\n1.push\n2.pop\n3.peep\n4.exit\n");
	scanf("%d",&ch);
	switch(ch) {
	case 1:push();display();break;
	case 2:pop();display();break;
	case 3:peep();break;
	case 4:printf("exiting");
	default: printf("wrong entry exiting\n");
               };
    getch();system("cls");

    
    }
return 0;
}
