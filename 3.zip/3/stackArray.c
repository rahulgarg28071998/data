#include<stdio.h>
#include<stdlib.h>

int arr[20];
int top=-1;

void push()
{
if(top>19) printf("overflow\n");
else
{top++;
printf("enter the number\n");
scanf("%d",&arr[top]);
}	
}

void pop()
{
	if(top==-1) printf("underflow\n");
	else {
		printf(" %d is poped",arr[top]);
		top--;
	}
}

void display()
{   
	int i=0;
	printf("\nthe stack is :");
	for(i=0;i<=top;i++)
	{
		printf("%d,",arr[i]);
	}
}
int main()
{
	int choice=0;
	while(choice<=4)
	{
		printf("menu\n1.push\n2.pop\n3.peep\n4.exit\n");
		scanf("%d",&choice);
		switch(choice) {
						case 1 :push();display();break;
						case 2 :pop();display();break;
						case 3 ://peep();break;
						default:printf("wrong entry\n");
}
getch();system("cls");

	}
	
	
}
